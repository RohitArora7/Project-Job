
<script>
callll();
    function callll(){
    
		$("#screen").load('profileview3.php')
    
    };
    

</script>
<div id="screen"></div>