<?php
// Connecting to database as mysqli_connect("hostname", "username", "password", "database name");
$con = mysqli_connect("localhost", "id1964882_rohit", "abc2020", "id1964882_test");
?>